import React from 'react';

export default function App() {
  return <h1>Welcome to Legion Records</h1>;
}
